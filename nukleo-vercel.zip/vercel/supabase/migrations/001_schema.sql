-- NUKLEO TRAINING · esquema, seguridad (RLS) y almacenamiento
create extension if not exists btree_gist;

create table admins (user_id uuid primary key references auth.users(id) on delete cascade);
create function is_admin() returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from admins where user_id = auth.uid()) $$;

create table categories (
  id serial primary key, slug text unique not null, name text not null,
  sort_order int not null default 0, published boolean not null default true);

create table products (
  id serial primary key, slug text unique not null, name text not null, description text not null default '',
  category_id int not null references categories(id), technique text not null,
  sizes text[] not null default '{}', colors text[] not null default '{}',
  featured boolean not null default false, sort_order int not null default 0,
  status text not null default 'draft' check (status in ('draft','published')),
  seo_title text, seo_description text, updated_at timestamptz not null default now());

create table product_images (
  id serial primary key, product_id int not null references products(id) on delete cascade,
  path text not null, url text not null default '', alt text not null default '', sort_order int not null default 0, is_cover boolean not null default false);

-- Tramos globales: única fuente para tabla pública, calculadora y mensajes
create table price_tiers (
  id serial primary key, min_qty int not null check (min_qty > 0), max_qty int check (max_qty is null or max_qty >= min_qty),
  exclude using gist (int4range(min_qty, coalesce(max_qty, 2147483647), '[]') with &&));
create table product_prices (
  product_id int references products(id) on delete cascade, tier_id int references price_tiers(id) on delete cascade,
  unit_price numeric(10,2) not null check (unit_price >= 0), primary key (product_id, tier_id));

-- Contenido editable: el borrador solo lo lee la administradora
create table site_content_published (key text primary key, value jsonb not null, updated_at timestamptz default now());
create table site_content_draft     (key text primary key, value jsonb not null, updated_at timestamptz default now());
-- Claves previstas: settings (whatsapp, plantilla, contacto), home, about, delivery, legal, seo, faq, appearance

alter table admins enable row level security;
alter table categories enable row level security; alter table products enable row level security;
alter table product_images enable row level security; alter table price_tiers enable row level security;
alter table product_prices enable row level security; alter table site_content_published enable row level security;
alter table site_content_draft enable row level security;

create policy "público lee categorías" on categories for select using (published or is_admin());
create policy "público lee productos publicados" on products for select using (status = 'published' or is_admin());
create policy "público lee imágenes" on product_images for select using (
  is_admin() or exists (select 1 from products p where p.id = product_id and p.status = 'published'));
create policy "público lee tramos" on price_tiers for select using (true);
create policy "público lee precios" on product_prices for select using (
  is_admin() or exists (select 1 from products p where p.id = product_id and p.status = 'published'));
create policy "público lee contenido publicado" on site_content_published for select using (true);
create policy "admin lee borrador" on site_content_draft for select using (is_admin());

do $$ declare t text; begin
  foreach t in array array['categories','products','product_images','price_tiers','product_prices','site_content_published','site_content_draft'] loop
    execute format('create policy "admin escribe" on %I for all using (is_admin()) with check (is_admin())', t);
  end loop; end $$;
-- La tabla admins no tiene políticas: nadie la modifica desde la web; se gestiona solo por SQL.

-- Imágenes: lectura pública, escritura solo admin, 5 MB, solo imágenes
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images','product-images', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
create policy "admin sube imágenes" on storage.objects for insert with check (bucket_id='product-images' and is_admin());
create policy "admin cambia imágenes" on storage.objects for update using (bucket_id='product-images' and is_admin());
create policy "admin borra imágenes" on storage.objects for delete using (bucket_id='product-images' and is_admin());
