-- Tarifas iniciales oficiales (14 productos). Quedan publicados.
insert into categories (slug,name,sort_order) values ('camisetas','Camisetas',1),('rashguards','Rashguards',2),('sudaderas','Sudaderas',3),('chandales','Chándales',4);
insert into price_tiers (min_qty,max_qty) values (25,39),(40,69),(70,null);
with p(name,cat,tech,a,b,c) as (values
('Camiseta técnica sublimada','camisetas','Sublimado',22,20,18),('Camiseta técnica DTF','camisetas','DTF',20,18,16),
('Camiseta de algodón bordada','camisetas','Bordado',22,20,18),('Camiseta técnica económica','camisetas','Económica',14,13,12),
('Rashguard sublimado','rashguards','Sublimado',25,22,20),('Rashguard de natación sublimado','rashguards','Sublimado',25,22,20),
('Sudadera de poliéster sublimada','sudaderas','Sublimado',30,27,25),('Sudadera de poliéster DTF','sudaderas','DTF',28,25,23),
('Sudadera de algodón bordada','sudaderas','Bordado',32,29,27),('Sudadera de algodón DTF','sudaderas','DTF',30,27,25),
('Chándal de poliéster sublimado','chandales','Sublimado',50,48,46),('Chándal de poliéster DTF','chandales','DTF',48,46,44),
('Chándal de algodón bordado','chandales','Bordado',54,52,50),('Chándal de algodón DTF','chandales','DTF',52,50,48)),
ins as (insert into products (slug,name,category_id,technique,sort_order,status)
  select lower(regexp_replace(translate(name,'áéíóúñÁÉÍÓÚ','aeiounAEIOU'),'[^a-zA-Z0-9]+','-','g')), name,
         (select id from categories where slug=p.cat), tech, row_number() over (), 'published' from p returning id, name)
insert into product_prices (product_id,tier_id,unit_price)
  select ins.id, t.id, case t.min_qty when 25 then p.a when 40 then p.b else p.c end
  from ins join p on p.name=ins.name cross join price_tiers t;
insert into site_content_published (key,value) values
('settings','{"whatsapp":"34608451380","template":"Hola, NUKLEO TRAINING. Quiero solicitar un presupuesto.\n\nProducto: {producto}.\nCategoría: {categoria}.\nTécnica: {tecnica}.\nCantidad: {cantidad} unidades.\nPrecio unitario orientativo: {precio} €.\nImporte total estimado: {total} €.{extra}\n\nMe gustaría consultar las opciones disponibles."}'),
('delivery','{"text":"En NUKLEO TRAINING ofrecemos atención personalizada a gimnasios, clubes y equipos deportivos. Disponemos de entrega en mano en determinadas localidades del sur de Madrid, previa coordinación. Para otras localidades, consulta las opciones de transporte al solicitar tu presupuesto."}');
