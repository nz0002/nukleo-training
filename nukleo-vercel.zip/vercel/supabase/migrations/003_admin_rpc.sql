-- Permite al panel saber si el usuario que ha iniciado sesión es administrador
create or replace function am_i_admin() returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from admins where user_id = auth.uid()) $$;
revoke all on function am_i_admin() from public; grant execute on function am_i_admin() to authenticated;
