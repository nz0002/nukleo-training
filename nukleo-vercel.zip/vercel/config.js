// Valores PÚBLICOS de Supabase (Settings → API). La seguridad la dan las políticas RLS, no el secreto de esta clave.
// Usa la clave "anon" / "publishable". NUNCA pongas aquí la clave service_role.
window.CONFIG = { SUPABASE_URL: "https://TU-PROYECTO.supabase.co", SUPABASE_ANON_KEY: "TU-CLAVE-ANON-PUBLICA" };
