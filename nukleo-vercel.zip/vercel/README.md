# NUKLEO TRAINING · web pública + panel (Vercel + Supabase)
Sin compilación: son archivos estáticos. `/` = web pública, `/admin` = panel. Ver los pasos en el mensaje de Claude.
Archivos: index.html, admin/index.html, style.css, config.js (tus claves públicas), logo.png, vercel.json, supabase/migrations/*.sql (ejecutar 001, 002, 003 en orden).
